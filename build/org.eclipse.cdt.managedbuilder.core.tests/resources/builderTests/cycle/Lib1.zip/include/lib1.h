#ifndef LIB1_H_
#define LIB1_H_

int lib1a(int);
int lib1b(int);

#endif /* LIB1_H_ */
