#include "lib1.h"
#include <lib2.h>

int lib1a(int x) {
	return lib2b(x);
}

int lib1b(int x) {
	return x + 1;
}
