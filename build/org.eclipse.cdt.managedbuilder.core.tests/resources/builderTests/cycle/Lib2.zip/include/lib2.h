#ifndef LIB2_H_
#define LIB2_H_

int lib2a(int);
int lib2b(int);

#endif /* LIB2_H_ */
