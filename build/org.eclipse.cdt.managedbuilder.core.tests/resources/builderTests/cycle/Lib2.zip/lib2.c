#include "lib2.h"
#include <lib1.h>

int lib2a(int x) {
	return lib1b(x);
}

int lib2b(int x) {
	return x - 1;
}
