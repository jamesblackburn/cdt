#include "lib1.h"
#include <lib3.h>

int lib1(int x) {
	return lib3(x);
}
