#include <lib1.h>
#include <lib2.h>

int main() {
	return lib1(1) + lib2(2);
}
