#ifndef LIB3_H_
#define LIB3_H_

int lib3(int);

#endif /* LIB3_H_ */
