#include "lib3.h"

int lib3(int x) {
	return x;
}
