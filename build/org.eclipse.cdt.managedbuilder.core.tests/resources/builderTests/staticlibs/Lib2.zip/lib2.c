#include "lib2.h"
#include <lib3.h>
#include <lib4.h>

int lib2(int x) {
	return lib3(x) + lib4(x);
}
