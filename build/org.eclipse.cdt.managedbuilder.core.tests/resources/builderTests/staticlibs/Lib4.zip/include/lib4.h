#ifndef LIB4_H_
#define LIB4_H_

int lib4(int);

#endif /* LIB4_H_ */
