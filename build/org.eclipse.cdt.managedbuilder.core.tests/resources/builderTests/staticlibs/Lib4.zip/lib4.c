#include "lib4.h"

int lib4(int x) {
	return x;
}

