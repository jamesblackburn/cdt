#include <sharedlib.h>

int main() {
	return sharedlib(0);
}
