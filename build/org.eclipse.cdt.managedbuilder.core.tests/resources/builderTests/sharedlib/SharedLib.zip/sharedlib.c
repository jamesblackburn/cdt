#include "sharedlib.h"
#include <staticlib.h>

int sharedlib(int x) {
	return staticlib(x) + 1;
}
