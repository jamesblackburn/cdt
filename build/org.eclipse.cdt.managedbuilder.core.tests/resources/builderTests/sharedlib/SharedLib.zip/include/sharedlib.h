#ifndef SHAREDLIB_H_
#define SHAREDLIB_H_

int sharedlib(int);

#endif /* SHAREDLIB_H_ */
