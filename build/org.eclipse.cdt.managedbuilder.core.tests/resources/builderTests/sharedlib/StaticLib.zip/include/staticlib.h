#ifndef STATICLIB_H_
#define STATICLIB_H_

int staticlib(int);

#endif /* STATICLIB_H_ */
