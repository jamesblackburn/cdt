#include "staticlib.h"

int staticlib(int x) {
	return x + 1;
}
