#include <lib2.h>

int main() {
	return lib2(0);
}
