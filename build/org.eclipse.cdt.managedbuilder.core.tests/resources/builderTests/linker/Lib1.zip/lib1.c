#include "lib1.h"
#include <lib2.h>

int lib1(int x) {
	return lib2(x);
}
