#ifndef LIB1_H_
#define LIB1_H_

int lib1(int);

#endif /* LIB1_H_ */
