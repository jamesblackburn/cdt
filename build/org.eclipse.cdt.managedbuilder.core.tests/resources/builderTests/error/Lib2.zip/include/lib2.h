#ifndef LIB2_H_
#define LIB2_H_

int lib2(int);

#endif /* LIB2_H_ */
