#include "lib2.h"

int lib2(int x) {
	return x + 1;
}
