#include <lib1.h>

int main() {
	return lib1(0);
}
